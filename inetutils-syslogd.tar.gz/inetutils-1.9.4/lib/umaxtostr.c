#define anytostr umaxtostr
#define inttype uintmax_t
#include "anytostr.c"
