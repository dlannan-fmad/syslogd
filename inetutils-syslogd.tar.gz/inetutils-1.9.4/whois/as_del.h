{
1877, 1901, "whois.ripe.net"}

,
{
2043, 2043, "whois.ripe.net"}

,
{
2047, 2047, "whois.ripe.net"}

,
{
2057, 2136, "whois.ripe.net"}

,
{
2585, 2614, "whois.ripe.net"}

,
{
2773, 2822, "whois.ripe.net"}

,
{
2830, 2879, "whois.ripe.net"}

,
{
3154, 3353, "whois.ripe.net"}

,
{
4608, 4863, "whois.apnic.net"}

,
{
5377, 5631, "whois.ripe.net"}

,
{
5800, 5927, "whois.nic.mil"}

,
{
6656, 6911, "whois.ripe.net"}

,
{
7467, 7722, "whois.apnic.net"}

,
{
8192, 9215, "whois.ripe.net"}

,
{
9261, 10239, "whois.apnic.net"}

,
{
12288, 13311, "whois.ripe.net"}

,
{
15360, 16383, "whois.ripe.net"}

,
